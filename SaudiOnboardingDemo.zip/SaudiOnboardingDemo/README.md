# Saudi Onboarding Demo - تطبيق iOS للتسجيل السعودي

تطبيق iOS كامل باستخدام SwiftUI لعملية Onboarding/KYC سعودي يحتوي على 9 خطوات كاملة.

## 🎯 المميزات

- ✅ **SwiftUI + MVVM Architecture**
- ✅ **9 خطوات متكاملة (Step 0 إلى Step 8)**
- ✅ **تصميم بألوان سعودية** (الأخضر #006C35)
- ✅ **OCR Demo** - استخراج بيانات الهوية السعودية
- ✅ **Face Matching Demo** - التحقق من الوجه
- ✅ **Validation محلي** مع Regex ورسائل خطأ عربية
- ✅ **MapKit Integration** - لتحديد المواقع
- ✅ **Progress Bar** - شريط التقدم في الأعلى
- ✅ **Auto-fill من OCR** - تعبئة تلقائية للأسماء
- ✅ **Camera Integration** - تصوير الهوية والوجه
- ✅ **جاهز للتوسع** - يمكن استبدال Services ب API حقيقي

## 📱 الخطوات

### Step 0: رقم الجوال + OTP
- إدخال رقم الجوال السعودي
- إرسال OTP وهمي للديمو
- التحقق من الرمز

### Step 1: بيانات KYC الأساسية
- الجنسية وحالة الإقامة
- رقم الهوية/الإقامة
- أسئلة PEP، المستفيد الحقيقي، US Person
- قطاع العمل

### Step 2: تصوير الهوية + OCR + Face Match ⭐
- تصوير الهوية الوطنية
- استخراج البيانات بالـ OCR (Demo)
- التقاط صورة سيلفي
- التحقق من الوجه (Demo - Always Success)

### Step 3: الأسماء
- الاسم بالعربي والإنجليزي
- تعبئة تلقائية من OCR
- الحقول المعبأة من OCR تكون Disabled

### Step 4: التواصل والحالة الاجتماعية
- البريد الإلكتروني
- المستوى التعليمي
- الحالة الاجتماعية
- اسم الزوج/الزوجة (إذا متزوج)
- بيانات الجواز (اختياري)

### Step 5: الوظيفة والدخل
- المهنة والدخل الشهري
- اسم جهة العمل
- تحديد موقع العمل على الخريطة
- رقم تعريف العمل

### Step 6: العنوان الوطني السعودي
- رقم المبنى، الشارع، الحي
- المدينة، الرمز البريدي، الرقم الإضافي
- رقم الوحدة (اختياري)
- تحديد موقع المنزل على الخريطة

### Step 7: بيانات الحساب والتوصيل
- نوع الحساب والعملة والفرع
- توصيل بطاقة ATM (المنزل/الفرع/عنوان آخر)
- IBAN سعودي (اختياري)

### Step 8: بيانات الدخول
- اسم المستخدم
- كلمة المرور وتأكيدها
- زر الإرسال النهائي

### Success Page
- صفحة نجاح مع ملخص كامل للبيانات
- بدون عرض الصور

## 🏗️ البنية المعمارية

```
SaudiOnboardingDemo/
├── Models/
│   ├── RegistrationData.swift      # ObservableObject - يحتوي على جميع البيانات
│   ├── SaudiIdOcrResponse.swift    # نموذج استجابة OCR
│   └── Enums.swift                 # جميع الـ Enums
│
├── Services/
│   ├── OcrService.swift            # Demo OCR Service
│   ├── FaceMatchService.swift      # Demo Face Match Service
│   └── ValidationService.swift     # Regex Validation
│
├── Utilities/
│   ├── Constants.swift             # الألوان والثوابت
│   └── RegexPatterns.swift         # جميع الـ Regex ورسائل الخطأ
│
├── Views/
│   ├── ContentView.swift           # الـ Navigation الرئيسي
│   ├── SuccessView.swift           # صفحة النجاح
│   │
│   ├── Components/
│   │   ├── ProgressBar.swift       # شريط التقدم
│   │   ├── CustomButton.swift      # أزرار مخصصة
│   │   ├── CustomTextField.swift   # حقول النص
│   │   ├── CustomPicker.swift      # القوائم المنسدلة
│   │   ├── ImagePicker.swift       # التقاط الصور
│   │   └── MapView.swift           # عرض الخريطة
│   │
│   └── Steps/
│       ├── Step0_PhoneOTPView.swift
│       ├── Step1_KYCBasicView.swift
│       ├── Step2_IDScanOCRView.swift
│       ├── Step3_NamesView.swift
│       ├── Step4_ContactMaritalView.swift
│       ├── Step5_JobIncomeView.swift
│       ├── Step6_NationalAddressView.swift
│       ├── Step7_AccountDetailsView.swift
│       └── Step8_LoginCredentialsView.swift
│
└── SaudiOnboardingDemoApp.swift    # Entry Point
```

## 🚀 كيفية التشغيل

### المتطلبات
- Xcode 15.0+
- iOS 16.0+
- Swift 5.9+

### الخطوات

1. **إنشاء مشروع Xcode جديد:**
   ```
   File → New → Project → iOS → App
   ```
   - **Product Name:** SaudiOnboardingDemo
   - **Interface:** SwiftUI
   - **Language:** Swift
   - **Minimum Deployment:** iOS 16.0

2. **نسخ الملفات:**
   - انسخ جميع المجلدات والملفات من `SaudiOnboardingDemo/` إلى مشروعك

3. **إضافة Permissions في Info.plist:**
   أضف المفاتيح التالية:
   ```xml
   <key>NSCameraUsageDescription</key>
   <string>نحتاج للوصول إلى الكاميرا لتصوير الهوية والتحقق من الوجه</string>

   <key>NSLocationWhenInUseUsageDescription</key>
   <string>نحتاج للوصول إلى موقعك لتحديد عنوان المنزل والعمل</string>
   ```

4. **تشغيل التطبيق:**
   - اضغط على Command + R أو زر Run
   - جرب التطبيق على Simulator أو جهاز حقيقي

## 🎨 الألوان المستخدمة

```swift
Primary:     #006C35  // الأخضر السعودي
Secondary:   #1E8E5A  // أخضر فاتح
Background:  #F8F9FA  // خلفية فاتحة
Success:     #28A745  // أخضر للنجاح
Error:       #DC3545  // أحمر للأخطاء
```

## ✅ Validation Patterns

جميع الـ Regex موجودة في `RegexPatterns.swift`:

- **رقم الجوال:** `^(009665|9665|\+9665|05|5)(5|0|3|6|4|9|1|8|7)([0-9]{7})$`
- **OTP:** `^\d{6}$`
- **رقم الهوية:** `^[12]\d{9}$`
- **الاسم العربي:** `^[\u0600-\u06FF\s]{2,}$`
- **الاسم الإنجليزي:** `^[A-Za-z\s]{2,}$`
- **Email:** قياسي
- **IBAN سعودي:** `^SA\d{22}$`
- **كلمة المرور:** 8 أحرف، حرف كبير، صغير، رقم، رمز خاص

## 🔧 Demo Services

### OcrService
```swift
// يرجع بيانات ثابتة للديمو:
- رقم الهوية: 1234567890
- الاسم بالعربي: محمد بن عبدالله بن أحمد
- الاسم بالإنجليزي: Mohammed Abdullah Ahmed
```

### FaceMatchService
```swift
// دائماً يرجع نجاح (Demo)
- isMatch: true
- confidence: 0.96
```

## 📝 ملاحظات مهمة

1. **Demo فقط:** هذا التطبيق Demo ولا يتصل بـ Backend حقيقي
2. **جاهز للتوسع:** جميع Services قابلة للاستبدال بـ API حقيقي
3. **الكاميرا:** يحتاج جهاز حقيقي لاختبار الكاميرا (Simulator لا يدعمها)
4. **MapKit:** يحتاج Location Permission على الجهاز الحقيقي

## 🎯 التطوير المستقبلي

- [ ] ربط بـ Backend API حقيقي
- [ ] إضافة OCR حقيقي (مثل Vision Framework أو Cloud OCR)
- [ ] إضافة Face Matching حقيقي
- [ ] حفظ البيانات محلياً (Core Data / UserDefaults)
- [ ] إضافة Unit Tests
- [ ] إضافة Localization (عربي/إنجليزي)
- [ ] تحسين UI/UX
- [ ] إضافة Dark Mode

## 📧 الدعم

للأسئلة أو المساعدة، يمكنك التواصل أو فتح Issue.

## 📄 الترخيص

هذا المشروع للاستخدام التعليمي والتجريبي.

---

**تم التطوير بواسطة:** Claude (Anthropic)
**التاريخ:** 2026
**الإصدار:** 1.0.0
